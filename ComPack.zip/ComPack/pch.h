﻿#ifndef PCH_H
#define PCH_H

#include "framework.h"
#include <combaseapi.h>
extern "C" _declspec(dllimport) 
VARIANT CreateObject(
	const WCHAR * __comname, 
	const WCHAR * __funcname, 
	int __count, 
	...);
#endif //PCH_H
