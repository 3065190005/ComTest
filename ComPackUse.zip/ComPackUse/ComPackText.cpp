﻿#include <iostream>
#include "pch.h"


int main()
{
	VARIANT __param1;

	// 参数类型为 ULONG
	__param1.vt = VT_BSTR;

	// 参数值为 1
	__param1.bstrVal = SysAllocString(L"notepad.exe");

	// 调用MyCom.FirstClass并调用Add 函数 参数数量为2 对Add函数传入参数__param1 和 __param2
	VARIANT __ret = CreateObject(L"Wscript.shell", L"run",1, __param1);
	SysFreeString(__param1.bstrVal);
}
